﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GestaoFacil.Server.Migrations
{
    /// <inheritdoc />
    public partial class erreionome : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
